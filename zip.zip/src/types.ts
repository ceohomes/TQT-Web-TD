export interface Group {
  id: string;
  code: string;
  name: string;
  description?: string;
  created_at?: string;
}

export interface RecruitmentStatus {
  id: string;
  name: string;
  color_bg?: string;
  color_text?: string;
  sort_order?: number;
  created_at?: string;
}

export interface Referrer {
  id: string;
  name: string;
  created_at?: string;
}

export interface Recruiter {
  id: string;
  name: string;
  created_at?: string;
}

export interface Candidate {
  id: string;
  stt?: number;           // Số thứ tự (tự động từ DB hoặc tính toán)
  group_type: string;     // Mã nhóm (link tới Group.code)
  full_name: string;      // Tên ứng viên
  birth_year?: string;    // Năm sinh
  phone?: string;         // Số điện thoại
  experience?: string;    // Kinh nghiệm/năng lực
  position?: string;      // Vị trí ứng tuyển
  desired_location?: string; // Địa điểm mong muốn làm việc
  referral_date?: string; // Ngày giới thiệu
  referrer?: string;      // Người giới thiệu
  send_bch_date?: string; // Ngày gửi BCH/ Phòng Nhân sự
  ptd_received?: boolean; // PTD nhận HS giới thiệu
  ptd_received_date?: string; // Ngày PTD nhận HS
  recruiter?: string;     // NS P.TD nhận
  recruitment_status?: string; // Tình trạng tuyển dụng
  tqt_interview?: string;     // TQT Phỏng vấn
  highlight_color?: string; // Màu highlight (green, blue, yellow, red, orange)
  notes?: string;         // Ghi chú
  cv_url?: string;        // Đường dẫn CV / link file PDF
  created_at?: string;
  updated_at?: string;
}

export interface Document {
  id: string;
  name: string;
  file_name: string;
  file_type: string;
  file_size?: number;
  storage_path: string;
  public_url?: string;
  created_at?: string;
  updated_at?: string;
}

export type ToastType = 'success' | 'error' | 'loading' | 'info';

export interface Toast {
  message: string;
  type: ToastType;
}
